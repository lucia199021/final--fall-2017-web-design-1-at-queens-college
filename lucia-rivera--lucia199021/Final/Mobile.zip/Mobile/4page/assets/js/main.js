(function($) {
    "use strict";
        jQuery(document).ready(function ($) {
  
   /* 
    -----------------------
    PrettyPhoto Js
    -----------------------
    */         
       $("a[rel^='prettyPhoto']").prettyPhoto();     
            
       
    }); // Ready
    
    
})(jQuery);